from random import randint
from art import logo
print(logo)
print("Welcome to the Number Guessing Game!")
print("I'm thinking of a number between 1 and 100.")
level = input("Choose a difficulty.Type 'easy' or 'hard': ")
target_num = random.randint(0, 101)
print(target_num)
n =10
f = 5
def num_guess_game(level,target_num,n,f):
  for i in range(0,11):
    if level == "easy":
      print(f"You have {n} attempts remaining to guess the number.")
      n -= 1
      guess_num = int(input("Make a guess: "))
      if guess_num == target_num:
        return guess_num
      elif guess_num > target_num:
        print("Too high.\nGuess again.")
      elif guess_num < target_num:
        print("Too low.\nGuess again.")
    else:
      
      print(f"You have {f} attempts remaining to guess the number.")
      f -= 1
      guess_num = int(input("Make a guess: "))
      if guess_num == target_num:
        return guess_num
      elif guess_num > target_num:
        print("Too high.\nGuess again.")
      elif guess_num < target_num:
        print("Too low.\nGuess again.")



guess_num = num_guess_game(level,target_num,n,f)
print(f"Congrats! You have chosen the correct number {guess_num}")
	




